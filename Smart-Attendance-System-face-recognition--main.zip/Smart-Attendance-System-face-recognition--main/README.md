# Smart-Attendance-System-face-recognition-
Smart Attendance System with Face Recognition using Java
